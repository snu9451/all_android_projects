package com.example.android_nds

import androidx.fragment.app.Fragment

class MapFragment : Fragment(R.layout.fragment_map) {

}